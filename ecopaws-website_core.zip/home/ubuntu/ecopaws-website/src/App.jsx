import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Heart, Leaf, Shield, Star, ShoppingCart, Menu, X, Search, User } from 'lucide-react'
import './App.css'

// Import images
import heroImage from './assets/1eNIXoZjC391.webp'
import productCollage from './assets/KiUMJVRORqU0.webp'
import sustainableProducts from './assets/ZVbWfpsgWbqM.jpg'
import groomingProducts from './assets/HEMUbzZ8M9X9.webp'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [cartItems, setCartItems] = useState(0)

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const addToCart = () => {
    setCartItems(cartItems + 1)
  }

  const featuredProducts = [
    {
      id: 1,
      name: "Organic Hemp Rope Toy",
      price: 24.99,
      image: productCollage,
      badge: "Bestseller",
      sustainability: "100% Organic Hemp"
    },
    {
      id: 2,
      name: "Recycled Plastic Dog Bed",
      price: 89.99,
      image: sustainableProducts,
      badge: "Eco-Friendly",
      sustainability: "Made from 15 Recycled Bottles"
    },
    {
      id: 3,
      name: "Natural Oatmeal Shampoo",
      price: 18.99,
      image: groomingProducts,
      badge: "Organic",
      sustainability: "Biodegradable Formula"
    },
    {
      id: 4,
      name: "Bamboo Food Bowl Set",
      price: 34.99,
      image: productCollage,
      badge: "Sustainable",
      sustainability: "Renewable Bamboo"
    }
  ]

  const categories = [
    {
      name: "Food & Treats",
      description: "Organic, ethically-sourced nutrition",
      icon: <Leaf className="w-8 h-8" />,
      image: sustainableProducts
    },
    {
      name: "Eco-Friendly Toys",
      description: "Playtime that's kind to the planet",
      icon: <Heart className="w-8 h-8" />,
      image: productCollage
    },
    {
      name: "Natural Grooming",
      description: "Chemical-free, biodegradable care",
      icon: <Shield className="w-8 h-8" />,
      image: groomingProducts
    }
  ]

  const testimonials = [
    {
      name: "Sarah M.",
      text: "I love that I can spoil my dog while still being environmentally conscious. The hemp rope toys are Max's absolute favorite!",
      rating: 5
    },
    {
      name: "David R.",
      text: "The organic dog food has made such a difference in Luna's coat and energy levels. Plus, the packaging is completely compostable!",
      rating: 5
    },
    {
      name: "Dr. Emily Chen",
      text: "As a veterinarian, I recommend EcoPaws to all my clients who want the best for their pets and the environment.",
      rating: 5
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-2">
              <Leaf className="w-8 h-8 text-primary" />
              <span className="text-2xl font-bold text-primary">EcoPaws</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-foreground hover:text-primary transition-colors">Home</a>
              <a href="#shop" className="text-foreground hover:text-primary transition-colors">Shop</a>
              <a href="#about" className="text-foreground hover:text-primary transition-colors">About</a>
              <a href="#sustainability" className="text-foreground hover:text-primary transition-colors">Sustainability</a>
              <a href="#contact" className="text-foreground hover:text-primary transition-colors">Contact</a>
            </nav>

            {/* Right side icons */}
            <div className="flex items-center space-x-4">
              <Search className="w-5 h-5 text-foreground hover:text-primary cursor-pointer transition-colors" />
              <User className="w-5 h-5 text-foreground hover:text-primary cursor-pointer transition-colors" />
              <div className="relative">
                <ShoppingCart className="w-5 h-5 text-foreground hover:text-primary cursor-pointer transition-colors" />
                {cartItems > 0 && (
                  <Badge className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center text-xs bg-accent">
                    {cartItems}
                  </Badge>
                )}
              </div>
              
              {/* Mobile menu button */}
              <button 
                className="md:hidden"
                onClick={toggleMenu}
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t">
              <nav className="flex flex-col space-y-4">
                <a href="#home" className="text-foreground hover:text-primary transition-colors">Home</a>
                <a href="#shop" className="text-foreground hover:text-primary transition-colors">Shop</a>
                <a href="#about" className="text-foreground hover:text-primary transition-colors">About</a>
                <a href="#sustainability" className="text-foreground hover:text-primary transition-colors">Sustainability</a>
                <a href="#contact" className="text-foreground hover:text-primary transition-colors">Contact</a>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative h-[70vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Premium Sustainable Pet Products
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Discover eco-friendly essentials that your pets will love and the planet will thank you for
          </p>
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-3">
            Shop Sustainable Now
          </Button>
        </div>
      </section>

      {/* Featured Categories */}
      <section id="shop" className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Shop by Category</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Explore our carefully curated collection of sustainable pet products
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:-translate-y-2">
                <CardHeader className="text-center">
                  <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit group-hover:bg-primary/20 transition-colors">
                    {category.icon}
                  </div>
                  <CardTitle className="text-xl">{category.name}</CardTitle>
                  <CardDescription>{category.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div 
                    className="h-48 bg-cover bg-center rounded-lg mb-4"
                    style={{ backgroundImage: `url(${category.image})` }}
                  ></div>
                  <Button className="w-full" variant="outline">
                    Shop Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Products</h2>
            <p className="text-lg text-muted-foreground">
              Our most popular sustainable pet products
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                <CardContent className="p-0">
                  <div className="relative">
                    <div 
                      className="h-48 bg-cover bg-center rounded-t-lg"
                      style={{ backgroundImage: `url(${product.image})` }}
                    ></div>
                    <Badge className="absolute top-2 left-2 bg-accent">
                      {product.badge}
                    </Badge>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-2">{product.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{product.sustainability}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-primary">${product.price}</span>
                      <Button size="sm" onClick={addToCart} className="opacity-0 group-hover:opacity-100 transition-opacity">
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose EcoPaws */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Pet Parents Choose EcoPaws</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <Leaf className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Sustainability First</h3>
              <p className="text-muted-foreground">Every product meets our strict environmental standards</p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <Star className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Premium Quality</h3>
              <p className="text-muted-foreground">Sustainable doesn't mean compromising on quality</p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Transparent Sourcing</h3>
              <p className="text-muted-foreground">Complete transparency about materials and processes</p>
            </div>
            <div className="text-center">
              <div className="mx-auto mb-4 p-3 bg-primary/10 rounded-full w-fit">
                <Heart className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Expert Curation</h3>
              <p className="text-muted-foreground">Hand-picked by pet and sustainability experts</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Pet Parents Are Saying</h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic">"{testimonial.text}"</p>
                  <p className="font-semibold">- {testimonial.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Stay Updated</h2>
          <p className="text-xl mb-8 opacity-90">Get 10% off your first order and stay informed about new sustainable products</p>
          <div className="max-w-md mx-auto flex gap-4">
            <Input 
              type="email" 
              placeholder="Enter your email" 
              className="bg-white text-foreground"
            />
            <Button variant="secondary" className="bg-accent hover:bg-accent/90 text-accent-foreground">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Leaf className="w-6 h-6 text-primary" />
                <span className="text-xl font-bold">EcoPaws</span>
              </div>
              <p className="text-muted-foreground mb-4">
                Premium sustainable pet products for conscious pet parents.
              </p>
              <p className="text-sm text-muted-foreground">
                Love Your Pet, Love Our Planet
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#shop" className="hover:text-primary transition-colors">Shop All</a></li>
                <li><a href="#about" className="hover:text-primary transition-colors">About Us</a></li>
                <li><a href="#sustainability" className="hover:text-primary transition-colors">Sustainability</a></li>
                <li><a href="#contact" className="hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Customer Service</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Shipping & Returns</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Size Guide</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Care Instructions</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Sustainability</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Our Impact</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Certifications</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Carbon Neutral Shipping</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Recycling Program</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 EcoPaws. All rights reserved. | Privacy Policy | Terms of Service</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

